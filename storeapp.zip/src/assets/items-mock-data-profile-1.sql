insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Zooxo', 'Mante LLC', 84, '2/14/2017', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.

Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.', 'Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.

Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.

Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.

Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 0, 0, '962', 1, 2, 'Lukken', 'HEB', 1, 'n/a', 'Otter, giant', 'rreace0', 1, 412, 7110, '11/9/2016', '37808-524', '1', 'permethrin');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Oyope', 'Lakin, Goodwin and Cole', 5, '11/27/2016', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.', 1, 1, '99', 1, 5, 'Oriole', 'Best Sanitizers, Inc', 0, 'Medical/Dental Instruments', 'Tern, white-winged', 'lgutowska1', 1, 263, 7312, '7/12/2017', '59900-130', '59', 'Benzalkonium Chloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Vipe', 'Leffler-Koch', 30, '1/31/2017', 'Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.', 'Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.

Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.

Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.

Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 'Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.', 1, 1, '4556', 1, 2, 'Kensington', 'Antigen Laboratories, Inc.', 0, 'Ordnance And Accessories', 'Bushbaby, large-eared', 'emcmurty2', 1, 319, 8516, '10/21/2016', '49288-0356', '667', 'Gambel Oak');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Livetube', 'Walker-Tremblay', 98, '7/24/2017', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.

Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.

Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', 1, 1, '60', 1, 2, 'Parkside', 'Merck Sharp & Dohme Corp.', 0, 'Aerospace', 'Spur-winged goose', 'daltofts3', 1, 792, 3884, '10/29/2016', '0006-4109', '749', 'Human Papillomavirus Quadrivalent (Types 6, 11, 16, and 18) Vaccine, Recombinant');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Browsedrive', 'White, Heathcote and Hermiston', 12, '8/5/2017', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 'Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.

Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.

Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.

Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.

Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.', 'Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 1, 1, '67090', 1, 1, 'Clyde Gallagher', 'LABORATOIRE NUXE', 1, 'Trucking Freight/Courier Services', 'Sociable weaver', 'apearce4', 1, 798, 1458, '12/15/2016', '67542-020', '13241', 'OCTINOXATE, AVOBENZONE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Quimba', 'Sporer-Cormier', 96, '10/25/2016', 'Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.', 'Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.

Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.

Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.', 0, 1, '9', 1, 6, 'Kennedy', 'Valu Merchandisers Company', 1, 'Natural Gas Distribution', 'Armadillo, giant', 'trettie5', 1, 765, 3082, '1/9/2017', '63941-351', '59493', 'Ranitidine Hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Aivee', 'Reinger, Hahn and Gutkowski', 3, '7/25/2017', 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.

In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 'Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.

Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.

Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.', 1, 0, '6', 1, 3, 'Westerfield', 'Choice Laboratories Limited', 0, 'Business Services', 'Land iguana', 'wleonida6', 1, 491, 7752, '3/9/2017', '63174-172', '35134', 'Sodium Monofluorophosphate');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Photobug', 'Mertz, Bogan and Hessel', 66, '5/26/2017', 'Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.

Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.', 1, 1, '23', 1, 2, 'Utah', 'Baxter Healthcare Corporation', 1, 'Oil & Gas Production', 'California sea lion', 'dmctaggart7', 1, 18, 3619, '6/10/2017', '10019-075', '75', 'Esmolol Hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Mydo', 'Lebsack-Davis', 21, '5/19/2017', 'Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.

In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.

Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.', 0, 0, '88', 1, 1, 'Bashford', 'St Marys Medical Park Pharmacy', 1, 'Real Estate', 'Darter, african', 'cmasser8', 1, 602, 7532, '11/5/2016', '60760-340', '0', 'LEVOTHYROXINE SODIUM');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Plambee', 'Schuppe, Marvin and Barrows', 22, '12/27/2016', 'In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.

Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.', 'Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.

In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 0, 1, '22', 1, 1, 'Lotheville', 'Physicians Total Care, Inc.', 1, 'n/a', 'Goose, egyptian', 'sdumbellow9', 1, 312, 7438, '7/11/2017', '54868-5500', '0378', 'pioglitazone hydrochloride and metformin hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Livetube', 'O''Kon LLC', 24, '1/25/2017', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.', 'Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.

Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.

Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 'Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 0, 0, '51', 1, 2, 'Algoma', 'Sagent Pharmaceuticals, Inc.', 0, 'n/a', 'Quoll, spotted-tailed', 'hantonika', 1, 165, 135, '3/10/2017', '25021-144', '46', 'ampicillin and sulbactam');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Feednation', 'Balistreri-Block', 39, '9/8/2017', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.

Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', 0, 0, '90', 1, 1, 'Center', 'Reckitt Benckiser LLC', 0, 'Trucking Freight/Courier Services', 'Lion, galapagos sea', 'tyandleb', 1, 226, 72, '10/28/2016', '63824-215', '11', 'acetaminophen, dextromethorphan hydrobromide, guaifenesin, and phenylephrine hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Mydo', 'Powlowski, Reinger and Huel', 19, '11/9/2016', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 0, 0, '5', 1, 5, 'Dawn', 'Cardinal Health', 0, 'Major Banks', 'Bonnet macaque', 'vhinchonc', 1, 393, 3733, '2/8/2017', '55154-5534', '544', 'Allopurinol');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Voomm', 'Stracke LLC', 40, '12/31/2016', 'Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.

Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.

Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.

Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.', 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.

In congue. Etiam justo. Etiam pretium iaculis justo.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.', 0, 1, '42', 1, 3, '5th', 'HyVee Inc', 1, 'Business Services', 'Gerbil (unidentified)', 'aadhamsd', 1, 63, 5391, '8/15/2017', '42507-105', '747', 'Acetaminophen');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Jatri', 'Gleason, Wintheiser and Rowe', 66, '7/6/2017', 'Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 0, 1, '2', 1, 1, 'Hallows', 'MAKEUP ART COSMETICS', 1, 'Home Furnishings', 'Sally lightfoot crab', 'ahurlle', 1, 641, 2850, '5/12/2017', '40046-0048', '542', 'OCTINOXATE, TITANIUM DIOXIDE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Photolist', 'Huels, Beier and Ebert', 26, '10/14/2016', 'Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.', 'In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.

Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.', 1, 1, '9', 1, 5, 'Walton', 'Medicine Shoppe International Inc', 0, 'n/a', 'Arctic fox', 'kcolombierf', 1, 927, 8531, '3/5/2017', '49614-897', '80282', 'Ibuprofen');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Zooveo', 'Cummerata-Weimann', 77, '6/12/2017', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.

Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.', 'Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.

Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 0, 0, '01', 1, 6, 'International', 'NCS HealthCare of KY, Inc dba Vangard Labs', 0, 'n/a', 'Darter, african', 'kcouveg', 1, 773, 5200, '4/12/2017', '0615-7696', '53', 'Fexofenadine');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Lazz', 'Stoltenberg-Crist', 28, '5/2/2017', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.

Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.

Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.

Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.', 0, 0, '6', 1, 3, 'Tony', 'ESTEE LAUDER INC', 1, 'Trucking Freight/Courier Services', 'Crab, sally lightfoot', 'griggeyh', 1, 18, 8521, '11/25/2016', '11559-023', '72', 'AVOBENZONE, OCTISALATE, and OCTOCRYLENE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Avamba', 'Stroman Group', 93, '12/31/2016', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.

Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.', 0, 0, '33', 1, 5, 'Eagan', 'Covis Pharmaceuticals Inc', 1, 'Air Freight/Delivery Services', 'Coatimundi, white-nosed', 'kbrafieldi', 1, 219, 3911, '6/4/2017', '24987-260', '3747', 'digoxin');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Kwideo', 'Abbott LLC', 33, '3/11/2017', 'Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.

In congue. Etiam justo. Etiam pretium iaculis justo.', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.

Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.', 0, 0, '2193', 1, 6, 'Starling', 'Rebel Distributors Corp', 1, 'Major Banks', 'Sage grouse', 'byearnej', 1, 336, 8214, '11/2/2016', '42254-145', '4059', 'Acetaminophen and Codeine Phosphate');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Agivu', 'Gleason, Mitchell and Douglas', 81, '7/23/2017', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.

Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.

Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.

In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 'Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.

Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 1, 1, '40', 1, 3, 'Service', 'Walgreen Company', 0, 'n/a', 'Toddy cat', 'acovetk', 1, 501, 3460, '6/9/2017', '0363-0345', '85331', 'Hydrocortisone');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Gigabox', 'McLaughlin and Sons', 88, '11/23/2016', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.

Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.

Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.', 'In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.', 0, 0, '57', 1, 6, 'Mifflin', 'Physicians Total Care, Inc.', 0, 'Air Freight/Delivery Services', 'Horned lark', 'pnapperl', 1, 92, 7680, '6/29/2017', '54868-5902', '51', 'oxycodone hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Voonyx', 'Hickle-Cole', 63, '5/3/2017', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', 1, 0, '6', 1, 5, 'Merchant', 'Global Pharmaceuticals, Division of Impax Laboratories Inc.', 1, 'Property-Casualty Insurers', 'Ostrich', 'awehnerm', 1, 956, 7356, '10/1/2016', '0115-1330', '18561', 'Dextroamphetamine Saccharate, Amphetamine Aspartate, Dextroamphetamine Sulfate and Amphetamine Sulfate');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Roodel', 'Skiles-Hirthe', 42, '11/3/2016', 'Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.', 'Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.', 0, 0, '1963', 1, 5, 'Rowland', 'Golden State Medical Supply, Inc.', 0, 'Package Goods/Cosmetics', 'Superb starling', 'aphilippsn', 1, 585, 5992, '8/22/2017', '60429-084', '2', 'Tranexamic Acid');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Jaxspan', 'Bergstrom, Koepp and Lemke', 89, '4/13/2017', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.', 'Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.', 1, 0, '46267', 1, 6, 'Dunning', 'McKesson Packaging Services Business Unit of McKesson Corporation', 0, 'Power Generation', 'Kangaroo, red', 'salbissero', 1, 749, 3371, '11/2/2016', '63739-285', '824', 'Diltiazem Hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Cogidoo', 'Zboncak LLC', 77, '9/14/2016', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.

Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.

Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.

In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', 0, 0, '47186', 1, 4, 'Hoard', 'Allegis Pharmaceuticals, LLC', 1, 'Major Pharmaceuticals', 'Green heron', 'zbonwellp', 1, 835, 3981, '3/22/2017', '28595-801', '56015', 'TRIPROLIDINE HYDROCHLORIDE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Wordtune', 'Armstrong-Glover', 81, '10/30/2016', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.

Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.

Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.', 'Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 1, 1, '43894', 1, 1, 'Warbler', 'Nelco Laboratories, Inc.', 0, 'Electronic Components', 'Giant armadillo', 'falstonq', 1, 703, 303, '4/15/2017', '36987-1193', '36506', 'Bluefish');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Brightdog', 'Stehr, Kilback and Gaylord', 30, '5/16/2017', 'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 'Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.', 1, 1, '8952', 1, 2, 'Walton', 'Forces of Nature', 0, 'Industrial Machinery/Components', 'Lava gull', 'lcestardr', 1, 168, 9286, '7/26/2017', '51393-7655', '64', 'Arnica Montana, Urtica Urens, Silicon Dioxide, and Thuja Occidentalis Root');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Chatterpoint', 'Grimes-Goyette', 65, '5/8/2017', 'Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.

Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', 'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 1, 0, '641', 1, 6, 'Ilene', 'Bare Escentuals Beauty, Inc.', 0, 'Professional Services', 'Bird, secretary', 'tmandreys', 1, 6, 9108, '12/4/2016', '98132-734', '29', 'Titanium Dioxide');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Zoomlounge', 'Satterfield and Sons', 56, '5/23/2017', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.

Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.

Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 1, 0, '32', 1, 2, 'Dexter', 'Aegerion Pharmaceuticals, Inc.', 1, 'Real Estate Investment Trusts', 'Crimson-breasted shrike', 'lbeggst', 1, 913, 5855, '12/14/2016', '76431-110', '989', 'lomitapide mesylate');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Wordtune', 'Gerlach Inc', 58, '9/2/2017', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.

Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.', 1, 1, '293', 1, 4, 'Susan', 'Walgreen Company', 1, 'n/a', 'Frogmouth, tawny', 'tatwoolu', 1, 445, 9688, '1/5/2017', '0363-0567', '49', 'Acetaminophen, Dextromethorphan HBr, Doxylamine succinate, Phenylephrine HCl');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Wikizz', 'Crooks, Walker and Wolf', 71, '10/30/2016', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.

Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.

Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 0, 0, '2', 1, 1, 'Londonderry', 'Aidarex Pharmaceuticals LLC', 1, 'Electric Utilities: Central', 'Quoll, spotted-tailed', 'eweldsv', 1, 654, 492, '8/26/2017', '33261-825', '911', 'Amlodipine Besylate and Benazepril Hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Oba', 'Mosciski, Hansen and Dietrich', 27, '2/18/2017', 'In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.

Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.

Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.', 1, 0, '44', 1, 6, 'Vera', 'Sun Pharma Global FZE', 1, 'Major Pharmaceuticals', 'Aardwolf', 'tsextyw', 1, 484, 1674, '6/16/2017', '47335-815', '57', 'Atomoxetine Hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Skilith', 'Dibbert, Reynolds and Rice', 50, '5/29/2017', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.', 'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.', 'Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.

Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 0, 0, '83', 1, 2, 'Hoard', 'SHISEIDO AMERICAS CORPORATION', 0, 'Real Estate Investment Trusts', 'Magistrate black colobus', 'fshoutex', 1, 645, 8550, '9/28/2016', '58411-111', '37221', 'OCTINOXATE and TITANIUM DIOXIDE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Topicware', 'Price, Schaefer and Hartmann', 14, '9/4/2017', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.

Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 0, 0, '97283', 1, 6, 'Ryan', 'Fenwal, Inc.', 1, 'Semiconductors', 'Praying mantis (unidentified)', 'achatelety', 1, 75, 7027, '1/2/2017', '0942-6503', '10462', 'Anticoagulant Citrate Phosphate Dextrose (CPD) Solution and ADSOL Preservation Solution');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Bluejam', 'Kessler Inc', 62, '8/26/2017', 'Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.

Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 0, 1, '42', 1, 5, 'Independence', 'BioActive Nutritional, Inc.', 1, 'Beverages (Production/Distribution)', 'Blackbuck', 'crickellz', 1, 869, 6541, '3/14/2017', '43857-0042', '79809', 'Arsenicum Album, Hepar Sulphuris Calcareum, Kali Bichromicum, Lycopodium Clavatum, Mercurius Solubilis');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Twitterwire', 'Pfannerstill, Kiehn and Cronin', 32, '12/20/2016', 'Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.

Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 0, 0, '883', 1, 3, 'Hanson', 'Ranbaxy Pharmaceuticals Inc.', 1, 'Biotechnology: Commercial Physical & Biological Resarch', 'Lemming, arctic', 'dsafell10', 1, 515, 4010, '10/6/2016', '63304-497', '06343', 'Hydrocodone Bitartrate and Acetaminophen');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Feedfire', 'Satterfield and Sons', 93, '9/10/2016', 'Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.

In congue. Etiam justo. Etiam pretium iaculis justo.', 'Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 1, 1, '668', 1, 2, 'Blaine', 'Shionogi Inc.', 1, 'Other Consumer Services', 'Fox, arctic', 'ataks11', 1, 860, 3906, '7/22/2017', '59630-485', '29', 'fenofibrate');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Jetpulse', 'Bradtke, Bednar and Mayer', 61, '5/27/2017', 'Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.

Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.

Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.

Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 'Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 'Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.

Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.

Curabitur at ipsum ac tellus semper interdum. Mauris ullamcorper purus sit amet nulla. Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam.', 1, 1, '6', 1, 6, 'Pearson', 'SigmaPharm Laboratories, LLC', 1, 'Major Banks', 'Dragon, ornate rock', 'cswaton12', 1, 403, 1484, '4/8/2017', '42794-006', '250', 'Ergocalciferol');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Meejo', 'Cole Inc', 25, '4/9/2017', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 'Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.

Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.', 1, 0, '5', 1, 6, 'Killdeer', 'State of Florida DOH Central Pharmacy', 0, 'Investment Bankers/Brokers/Service', 'Mynah, common', 'mmottini13', 1, 589, 290, '1/2/2017', '53808-0436', '8720', 'Ibuprofen');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Kanoodle', 'Feest-Greenfelder', 6, '4/26/2017', 'Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.

Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.', 0, 0, '0', 1, 3, 'Weeping Birch', 'REMEDYREPACK INC.', 1, 'Construction/Ag Equipment/Trucks', 'Cat, native', 'kfairbourn14', 1, 550, 8060, '9/13/2016', '52125-824', '332', 'Levothyroxine Sodium');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Quaxo', 'Gleason-Cole', 80, '7/19/2017', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.

Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.

Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.

Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.

Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.

Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.', 0, 0, '82142', 1, 1, 'Hazelcrest', 'Rite Aid Corporation', 0, 'n/a', 'Cuis', 'gmundle15', 1, 473, 366, '11/26/2016', '11822-1110', '0448', 'Clotrimazole');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Tekfly', 'Kuhn, Murray and Botsford', 88, '11/25/2016', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.

Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.', 0, 1, '88915', 1, 3, 'Loeprich', 'STAT RX USA LLC', 1, 'Industrial Specialties', 'Vulture, turkey', 'dkime16', 1, 65, 9052, '1/24/2017', '16590-595', '1', 'QUININE SULFATE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Tazzy', 'Gleason-Davis', 1, '11/19/2016', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.', 'In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.

Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.', 'Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 1, 0, '62', 1, 2, 'Sunfield', 'BRACCO DIAGNOSTICS INC', 1, 'Other Consumer Services', 'Heron, green-backed', 'gphilps17', 1, 347, 2352, '1/13/2017', '0270-1315', '8003', 'IOPAMIDOL');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Skiptube', 'Sanford, Howell and Bartell', 74, '9/4/2017', 'Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.

Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.', 'Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.', 'Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.

Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.', 0, 0, '56688', 1, 3, 'Gina', 'Cardinal Health', 1, 'Water Supply', 'North American porcupine', 'sassante18', 1, 993, 7291, '11/20/2016', '55154-9564', '142', 'BUPIVACAINE HYDROCHLORIDE,EPINEPHRINE BITARTRATE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Skyvu', 'Kulas Inc', 64, '5/4/2017', 'In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.

Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', 'Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 1, 0, '9773', 1, 3, 'Eagan', 'Legacy Pharmaceutical Packaging', 1, 'Medical/Dental Instruments', 'North American porcupine', 'sbudibent19', 1, 126, 967, '4/22/2017', '68645-310', '6', 'Atenolol');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Voomm', 'Breitenberg Inc', 97, '10/26/2016', 'Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.

Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.

Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.', 'In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', 'Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.

In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', 0, 0, '08', 1, 3, 'Coleman', 'Amerisource Bergen', 1, 'Major Banks', 'Flicker, campo', 'dbamford1a', 1, 75, 7698, '2/14/2017', '46122-004', '245', 'Acetaminophen, Phenylephrine HCl');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Zoomlounge', 'Durgan-Luettgen', 69, '11/20/2016', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.

Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.

Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 0, 0, '89009', 1, 3, 'Eagan', 'Kalispell Medical Equipment', 0, 'Investment Bankers/Brokers/Service', 'Tiger cat', 'falldis1b', 1, 923, 8222, '7/23/2017', '60696-1234', '88489', 'OXYGEN');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Topicshots', 'Bahringer, Ledner and Tremblay', 69, '9/1/2017', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.', 'In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 'Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 0, 1, '857', 1, 4, 'Grayhawk', 'HEB', 0, 'Food Distributors', 'African fish eagle', 'kfurst1c', 1, 113, 1721, '12/14/2016', '37808-290', '0927', 'TRICLOSAN');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Devshare', 'Mante-Waelchi', 48, '1/13/2017', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.

Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.', 'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 0, 0, '543', 1, 6, 'North', 'Hospira, Inc.', 0, 'Major Pharmaceuticals', 'Caiman, spectacled', 'mpayze1d', 1, 925, 2879, '2/15/2017', '0409-1639', '965', 'FUROSEMIDE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Zoomlounge', 'Howe-Ratke', 18, '7/29/2017', 'Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 'In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.

Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', 1, 1, '581', 1, 1, 'Vermont', 'Dispensing Solutions, Inc.', 0, 'Telecommunications Equipment', 'Vulture, lappet-faced', 'tsnedker1e', 1, 702, 5194, '4/16/2017', '55045-3693', '200', 'AZITHROMYCIN');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Avavee', 'Toy, Rippin and Boyle', 93, '12/29/2016', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.', 'Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.

Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.', 'Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 0, 1, '15', 1, 5, 'Lukken', 'Walgreens Co', 1, 'Investment Bankers/Brokers/Service', 'Eagle, white-bellied sea', 'kstronough1f', 1, 61, 4939, '6/15/2017', '0363-0045', '4', 'eucalyptol, menthol, methyl salicylate, thymol');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Wikibox', 'Turcotte LLC', 60, '5/7/2017', 'Proin eu mi. Nulla ac enim. In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem.

Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.', 'Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 'Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.', 1, 0, '07456', 1, 6, 'Thompson', 'Laboratoires Boiron', 0, 'Hotels/Resorts', 'Skink, african', 'mllelweln1g', 1, 912, 4195, '1/2/2017', '0220-9061', '25', 'ONION, AMBROSIA ARTEMISIIFOLIA, HISTAMINE DIHYDROCHLORIDE, SCHOENOCAULON OFFICINALE SEED, EUPHRASIA STRICTA, SOLIDAGO VIRGAUREA FLOWERING TOP');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Mydeo', 'Leannon, Ebert and Carroll', 15, '6/23/2017', 'Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.

Phasellus in felis. Donec semper sapien a libero. Nam dui.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.

Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.

Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.', 1, 1, '0', 1, 6, 'Talmadge', 'Lake Erie Medical DBA Quality Care Products LLC', 0, 'Building Products', 'Peacock, blue', 'sarchibold1h', 1, 74, 6592, '12/17/2016', '35356-903', '5667', 'acyclovir');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('InnoZ', 'Pouros-Cormier', 10, '7/9/2017', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.

Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.

Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.', 'Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.', 1, 0, '86875', 1, 3, 'Mallory', 'Rebel Distributors Corp', 0, 'Consumer Electronics/Appliances', 'Eagle, african fish', 'hfrickey1i', 1, 451, 3673, '3/22/2017', '21695-208', '6122', 'Hydroxyzine Hydrochloride');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Ainyx', 'Labadie, Kihn and Volkman', 26, '7/23/2017', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.

Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.', 'Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.

Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.', 'Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.

Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.', 1, 1, '18875', 1, 3, 'Nobel', 'KAISER FOUNDATION HOSPITALS', 0, 'n/a', 'Cheetah', 'ipriden1j', 1, 348, 4769, '1/7/2017', '0179-0116', '381', 'Hydrocodone Bitartrate And Acetaminophen');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Oyoloo', 'Daugherty, Terry and Powlowski', 25, '6/14/2017', 'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.', 'In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.', 'In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', 0, 0, '81883', 1, 5, 'Charing Cross', 'Baxter Healthcare Corporation', 1, 'Major Pharmaceuticals', 'Dog, bush', 'mhalsho1k', 1, 580, 8215, '8/12/2017', '10019-016', '58743', 'Glycopyrrolate');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Ntags', 'Rutherford-Braun', 73, '4/23/2017', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.

Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.

In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 'Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', 1, 1, '206', 1, 1, 'Sutherland', 'REMEDYREPACK INC.', 1, 'Hospital/Nursing Management', 'Possum, pygmy', 'oscutts1l', 1, 449, 105, '4/7/2017', '52125-966', '09', 'pantoprazole sodium');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Brainlounge', 'Doyle, Kunde and O''Reilly', 89, '1/18/2017', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.

Cras non velit nec nisi vulputate nonummy. Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque.

Quisque porta volutpat erat. Quisque erat eros, viverra eget, congue eget, semper rutrum, nulla. Nunc purus.', 'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.

Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.', 'In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.

Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.', 0, 0, '92381', 1, 5, 'Waxwing', 'Reckitt Benckiser LLC', 1, 'Computer Communications Equipment', 'Long-finned pilot whale', 'icecchi1m', 1, 299, 3263, '7/29/2017', '63824-261', '867', 'ACETAMINOPHEN, GUAIFENESIN, and PHENYLEPHRINE HYDROCHLORIDE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Babblestorm', 'Fadel LLC', 28, '6/11/2017', 'Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.

In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.

In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.

In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.', 0, 0, '94290', 1, 2, 'Cherokee', 'Golden State Medical Supply, Inc.', 0, 'Major Chemicals', 'White-fronted bee-eater', 'psheran1n', 1, 554, 5555, '3/21/2017', '60429-720', '40', 'Famotidine');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Feedmix', 'Waelchi LLC', 14, '1/13/2017', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin risus. Praesent lectus.

Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.

Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.

Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 'Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', 1, 1, '3452', 1, 2, 'Summit', 'Nelco Laboratories, Inc.', 1, 'Precious Metals', 'Squirrel, nelson ground', 'cthumann1o', 1, 26, 3684, '12/15/2016', '36987-2120', '962', 'Trichoderma harzianam');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Cogibox', 'Halvorson-Cassin', 100, '5/17/2017', 'Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.

Morbi porttitor lorem id ligula. Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem.

Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.

In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.

In congue. Etiam justo. Etiam pretium iaculis justo.

In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.', 'Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.

Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.', 0, 1, '7747', 1, 2, 'Manitowish', 'Chain Drug Consortium, LLC (Premier Value)', 1, 'Finance: Consumer Services', 'Eagle, african fish', 'wlinay1p', 1, 302, 1072, '8/4/2017', '68016-117', '76835', 'SENNOSIDES');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Demimbu', 'Barrows-Zulauf', 86, '6/4/2017', 'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.

Praesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.

Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.

Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.', 1, 0, '783', 1, 5, 'Crowley', 'Mylan Pharmaceuticals Inc.', 1, 'n/a', 'Dove, rock', 'bbenediktsson1q', 1, 366, 4449, '6/6/2017', '0378-2660', '695', 'morphine sulfate');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Quaxo', 'Waelchi-Breitenberg', 24, '3/9/2017', 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.

In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.', 'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.

Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.

Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.', 1, 0, '7053', 1, 1, 'Fordem', 'State of Florida DOH Central Pharmacy', 1, 'Beverages (Production/Distribution)', 'Lion, mountain', 'lhaszard1r', 1, 33, 1108, '7/27/2017', '53808-0352', '67988', 'CLONIDINE HYDROCHLORIDE');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Thoughtbeat', 'Keeling-Harvey', 85, '9/23/2016', 'Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.

Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat. Vestibulum sed magna at nunc commodo placerat.', 'Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.

Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.', 'Sed ante. Vivamus tortor. Duis mattis egestas metus.

Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 1, 1, '21140', 1, 4, 'Del Mar', 'Apotex Corp', 0, 'Railroads', 'Crab-eating raccoon', 'jfillgate1s', 1, 514, 9622, '7/18/2017', '60505-2586', '163', 'Risperidone');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Skinder', 'Mraz-Zboncak', 68, '1/15/2017', 'Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

Proin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.

Aenean lectus. Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.

Curabitur in libero ut massa volutpat convallis. Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo. Maecenas pulvinar lobortis est.

Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.', 'Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.

Sed ante. Vivamus tortor. Duis mattis egestas metus.

Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.', 'Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo. Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.

Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam. Suspendisse potenti.

Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', 1, 1, '6024', 1, 5, 'Kropf', 'Jubilant HollisterStier LLC', 1, 'Oil Refining/Marketing', 'Porcupine, crested', 'pmaccoughan1t', 1, 918, 6202, '9/17/2016', '65044-6691', '5192', 'Standardized Mite Mix, Dermatophagoides pteronyssinus and Dermatophagoides farinae, 10000 AU per mL');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Roodel', 'Maggio and Sons', 21, '3/29/2017', 'Aenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.

Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.

Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue. Aliquam erat volutpat.', 'Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.

Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.

Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.', 'Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.

Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.', 0, 1, '04697', 1, 2, 'Muir', 'KEDRION BIOPHARMA, INC', 0, 'Business Services', 'Ground legaan', 'svida1u', 1, 800, 7133, '8/3/2017', '76125-785', '6947', 'Albumin (Human)');
insert into Items (Brand, Carrier, Cost, CreationDateTime, Description, Detail, Feature, HasFreeShipping, HasLocalPickup, Height, IsActive, ItemCategoryId, Location, Manufacturer, ManufacturingType, Material, Name, ProcessingTime, ProfileId, Quantity, Price, UpdatedDateTime, VerificationCode, Weight, Title) values ('Linklinks', 'Schmeler, McCullough and Wintheiser', 65, '10/9/2016', 'In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.

Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.', 'Duis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.

In sagittis dui vel nisl. Duis ac nibh. Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus.

Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.

Maecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.

Curabitur gravida nisi at nibh. In hac habitasse platea dictumst. Aliquam augue quam, sollicitudin vitae, consectetuer eget, rutrum at, lorem.', 'Fusce consequat. Nulla nisl. Nunc nisl.

Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.', 1, 1, '7055', 1, 3, 'Sunfield', 'Direct Rx', 1, 'n/a', 'African skink', 'mdickinson1v', 1, 443, 6769, '8/12/2017', '61919-047', '9', 'PROMETHAZINE HYDROCHLORIDE');