import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ItemService } from '../../../service/item.service';
import { NotificationsService } from 'angular2-notifications';


@Component({
    selector: 'additem-component',
    templateUrl: './additem.component.html',
    styleUrls: ['./additem.component.css']
})
export class AddItemComponent implements OnInit {
    // @ViewChild('file') fileElement:ElementRef;
    itemForm: FormGroup;
    isLoading = false;
    ngOnInit(): void {
        this.itemForm = this.formBuilder.group({
            title: ['', [Validators.required, Validators.minLength(4)]],
            name: ['', [Validators.required, Validators.minLength(4)]],
            description: '',
            price: ['', [Validators.required, Validators.pattern(/^(\d*\.\d{1,2}|\d+)$/)]],
            manufacturer: ['', [Validators.required, Validators.minLength(4)]],
            manufacturingType: ''
        });
    }
    constructor(private itemService: ItemService, private notification: NotificationsService,
        private router: Router, private formBuilder: FormBuilder) { }
    add(e) {
        e.preventDefault();
        this.isLoading = true;
        const result = {
            context: this,
            success(e) {
                console.log(e);
                if (e.statusCode === 201) {
                    result.context.notification.success(
                        'Success',
                        'Item has been created successfully!',
                        {
                            showProgressBar: true,
                            pauseOnHover: true,
                            clickToClose: true,
                            timeOut: 3000
                        }
                    );
                    // result.context.router.navigate(['/home/business/manage/item/edit/', { queryParams: { id: e.item.id}}]);
                    result.context.isLoading = false;
                    result.context.router.navigate(['/profile/business/manage/item/edit', e.item.id]);
                }
            }
        };
        this.itemService.add(this.itemForm.value, result);
    }

    get title() { return this.itemForm.get('title'); }
    get name() { return this.itemForm.get('name'); }
    get price() { return this.itemForm.get('price'); }
    get description() { return this.itemForm.get('description'); }
    get manufacturer() { return this.itemForm.get('manufacturer'); }
    get manufacturingType() { return this.itemForm.get('manufacturingType'); }
}
