
import { Component } from '@angular/core';




@Component({
    selector: 'homebanner-component',
    templateUrl: './homebanner.component.html',
    styleUrls: ['./homebanner.component.css']
})
export class HomeBannerComponent {

    constructor() {

    }
}
