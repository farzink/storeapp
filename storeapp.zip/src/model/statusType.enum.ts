export enum StatusType {
    Open = 1,
    Closed = 2
}
