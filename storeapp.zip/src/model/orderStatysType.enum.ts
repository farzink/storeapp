export enum OrderStatusTypes {
    Open = 1,
    Closed = 2,
    HavingIssues = 3
}
