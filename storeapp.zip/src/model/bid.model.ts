export class BidViewModel {
    auctionId: number;
    bidId: number;
    amount: number;
}
