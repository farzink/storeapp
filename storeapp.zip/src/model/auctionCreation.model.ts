export class AuctionCreation {
    itemId: number;
    coolingOutInterval: number;
    initialPrice: number;
    title: string;
    description: string;
    endDate: Date;
    deletionPolicyInMintues: number;
    minimumIncreament: number;
}
