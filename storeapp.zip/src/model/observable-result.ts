import { WebCallResult } from '../utility/webcall-result';
export class ObservableResult{
    success(){}
    error(){}
    complete(){}
}